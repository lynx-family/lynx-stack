// Copyright 2024 The Lynx Authors. All rights reserved.
// Licensed under the Apache License Version 2.0 that can be found in the
// LICENSE file in the root directory of this source tree.
export interface PerformanceEntry {
    name: string;
    entryType: string;
    typeResolved: boolean;
}

export interface FrameworkRenderingTiming {
    vmExecuteStart: number;
    vmExecuteEnd: number;
    dataProcessorStart: number;
    dataProcessorEnd: number;
    setInitDataStart: number;
    setInitDataEnd: number;
}

export interface FrameworkRenderingTimings {
}

export interface PipelineEntry extends PerformanceEntry {
    identifier: string;
    pipelineStart: number;
    pipelineEnd: number;
    mtsRenderStart: number;
    mtsRenderEnd: number;
    resolveStart: number;
    resolveEnd: number;
    layoutStart: number;
    layoutEnd: number;
    paintingUiOperationExecuteStart: number;
    paintingUiOperationExecuteEnd: number;
    layoutUiOperationExecuteStart: number;
    layoutUiOperationExecuteEnd: number;
    paintEnd: number;
    frameworkRenderingTiming: FrameworkRenderingTimings[keyof FrameworkRenderingTimings] & FrameworkRenderingTiming;
    hostPlatformTiming: HostPlatformTiming;
    actualFmp?: PerformanceMetric;
    lynxActualFmp?: PerformanceMetric;
    totalActualFmp?: PerformanceMetric;
}

export interface LoadBundleEntry extends PipelineEntry {
    loadBundleStart: number;
    loadBundleEnd: number;
    parseStart: number;
    parseEnd: number;
    loadBackgroundStart: number;
    loadBackgroundEnd: number;
    verifyTasmStart: number;
    verifyTasmEnd: number;
    ffiStart: number;
    ffiEnd: number;
    createLynxStart: number;
    createLynxEnd: number;
    loadCoreStart: number;
    loadCoreEnd: number;
    openTime: number;
    containerInitStart: number;
    containerInitEnd: number;
    prepareTemplateStart: number;
    prepareTemplateEnd: number;
    fcp?: PerformanceMetric;
    lynxFcp: PerformanceMetric;
    totalFcp?: PerformanceMetric;
}

/**
 * @deprecated LoadBundleEntry and ReloadBundleEntry contain all properties of InitContainerEntry
 **/
export interface InitContainerEntry extends PerformanceEntry {
    openTime: number;
    containerInitStart: number;
    containerInitEnd: number;
    prepareTemplateStart: number;
    prepareTemplateEnd: number;
    extraTiming: Record<string, number>;
}

/**
 * @deprecated LoadBundleEntry and ReloadBundleEntry contain all properties of InitLynxviewEntry
 **/
export interface InitLynxviewEntry extends PerformanceEntry {
    createLynxStart: number;
    createLynxEnd: number;
}

/**
 * @deprecated LoadBundleEntry and ReloadBundleEntry contain all properties of InitBackgroundRuntimeEntry
 **/
export interface InitBackgroundRuntimeEntry extends PerformanceEntry {
    loadCoreStart: number;
    loadCoreEnd: number;
}

export interface PerformanceMetric {
    name: string;
    duration: number;
    startTimestampName: string;
    startTimestamp: number;
    endTimestampName: string;
    endTimestamp: number;
}

/**
 * @deprecated LoadBundleEntry and ReloadBundleEntry contain all properties of MetricFcpEntry
 **/
export interface MetricFcpEntry extends PerformanceEntry {
    fcp: PerformanceMetric;
    lynxFcp: PerformanceMetric;
    totalFcp: PerformanceMetric;
}

export interface MetricFspEntry extends PerformanceEntry {
    fsp: PerformanceMetric;
    lynxFsp: PerformanceMetric;
    totalFsp: PerformanceMetric;
    fspStatus: string;
    contentFillPercentageX: number;
    contentFillPercentageY: number;
    contentFillPercentageTotalArea: number;
    containerFillPercentageContainerArea: number;
}

/**
 * @deprecated PipelineEntry contain all properties of MetricActualFmpEntry
 **/
export interface MetricActualFmpEntry extends PerformanceEntry {
    actualFmp: PerformanceMetric;
    lynxActualFmp: PerformanceMetric;
    totalActualFmp: PerformanceMetric;
}

/**
 * @deprecated Due to the influence of long tasks on this metric, the statistical results are 
 * inaccurate, so this type has been deprecated. 
 * Since version 3.3, you will no longer receive this event.
 **/
export interface MetricTtiEntry extends PerformanceEntry {
    tti: PerformanceMetric;
    lynxTti: PerformanceMetric;
    totalTti: PerformanceMetric;
}

export interface ReloadBundleEntry extends PipelineEntry {
    reloadBundleStart: number;
    reloadBundleEnd: number;
    reloadBackgroundStart: number;
    reloadBackgroundEnd: number;
    ffiStart: number;
    ffiEnd: number;
    createLynxStart: number;
    createLynxEnd: number;
    loadCoreStart: number;
    loadCoreEnd: number;
    openTime: number;
    containerInitStart: number;
    containerInitEnd: number;
    prepareTemplateStart: number;
    prepareTemplateEnd: number;
    fcp?: PerformanceMetric;
    lynxFcp: PerformanceMetric;
    totalFcp?: PerformanceMetric;
}

export interface MemoryUsageEntry extends PerformanceEntry {
    sizeBytes: number;
    detail: Record<string, MemoryUsageItem>;
}

export interface MemoryUsageItem {
    category: string;
    sizeBytes: number;
    detail: Record<string, string>;
}

export interface LazyBundleEntry extends PerformanceEntry {
    componentUrl: string;
    mode: string;
    size: number;
    sync: boolean;
    loadSuccess: boolean;
    requireStart: number;
    requireEnd: number;
    decodeStart: number;
    decodeEnd: number;
}

export interface AndroidHostPlatformTiming {
    hostPlatformType: 'Android';
    measureStart: number;
    measureEnd: number;
    layoutStart: number;
    layoutEnd: number;
    drawStart: number;
    drawEnd: number;
}

export interface IOSHostPlatformTiming {
    hostPlatformType: 'iOS';
}

export interface HarmonyHostPlatformTiming {
    hostPlatformType: 'Harmony';
}

export type HostPlatformTiming = AndroidHostPlatformTiming | IOSHostPlatformTiming | HarmonyHostPlatformTiming